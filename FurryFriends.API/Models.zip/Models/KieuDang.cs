﻿namespace FurryFriends.API.Models
{
    public class KieuDang
    {
    }
}
