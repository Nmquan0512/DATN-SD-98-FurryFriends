﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FurryFriends.API.Models
{
	public class HoaDon
	{
		[Key]
		public Guid HoaDonId { get; set; }

		[Required]
		public Guid TaiKhoanId { get; set; }

		public Guid? VoucherId { get; set; }

		[Required]
		public Guid KhachHangId { get; set; }

		[Required]
		public Guid HinhThucThanhToanId { get; set; }

		public string TenCuaKhachHang { get; set; }
		public string SdtCuaKhachHang { get; set; }
		public string EmailCuaKhachHang { get; set; }

		[Required]
		public DateTime NgayTao { get; set; }
		public DateTime? NgayNhanHang { get; set; }

		[Required]
		public decimal TongTienSauKhiGiam { get; set; }

		[Required]
		public int TrangThai { get; set; }

		public string GhiChu { get; set; }

		[ForeignKey("VoucherId")]
		public virtual Voucher Voucher { get; set; }

		[ForeignKey("TaiKhoanId")]
		public virtual TaiKhoan TaiKhoan { get; set; }

		[ForeignKey("KhachHangId")]
		public virtual KhachHang KhachHang { get; set; }

		[ForeignKey("HinhThucThanhToanId")]
		public virtual HinhThucThanhToan HinhThucThanhToan { get; set; }

		public virtual ICollection<HoaDonChiTiet> HoaDonChiTiets { get; set; }
	}
}